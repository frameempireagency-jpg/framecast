#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Setup and Tools: real Mac instructions, and the receptionist section."""
import io, sys

FAIL = []
def sub(s, old, new, label, count=1):
    n = s.count(old)
    if n != count:
        FAIL.append(f"{label}: expected {count}, found {n}")
        return s
    return s.replace(old, new)

p = "FE_Setup_And_Tools.html"
s = io.open(p, encoding="utf-8").read()

# ---------------------------------------------------------------- Mac
MAC = """<h3>Mac</h3>
<div class="note warn">
  <div class="lab">CHECK THIS FIRST, IT TAKES TEN SECONDS</div>
  <p>The Mac build only runs on <b>Apple Silicon</b> Macs, which means M1, M2, M3 or M4. It will not run on an
  older Intel Mac at all, and there is nothing you can do to make it. Click the Apple logo top left, then
  <b>About This Mac</b>. If the Chip line says M-anything you are fine. If it says Intel, message Andrei and use a
  Windows machine or your phone for now.</p>
</div>
<ol>
  <li>Download <code>FrameCast-mac.zip</code> and double click it to unzip.</li>
  <li>Drag <b>FrameCast</b> into your <b>Applications</b> folder. Do not run it from Downloads.</li>
  <li>Try to open it. macOS will refuse and say it cannot be opened or cannot check it for malicious software.
  <b>This is expected.</b> It happens because the app is not signed with an Apple developer certificate yet, not
  because anything is wrong with it.</li>
  <li>Go to the Apple menu, <b>System Settings</b>, then <b>Privacy &amp; Security</b>. Scroll down. There will be a
  line about FrameCast being blocked with a button that says <b>Open Anyway</b>. Click it, then confirm.</li>
  <li>On newer versions of macOS, right clicking and choosing Open no longer works for this. You have to use the
  Privacy &amp; Security screen above.</li>
  <li>First launch asks for screen recording, microphone and camera. Grant all three. Screen recording usually needs
  you to quit and reopen the app before it takes effect.</li>
  <li>Sign in with your <code>@frameempire.co.uk</code> email.</li>
</ol>
<div class="note warn">
  <div class="lab">TWO THINGS THAT WILL CONFUSE YOU</div>
  <p>The permission boxes may say <b>Cap</b> rather than FrameCast. That is a leftover from the app it is built on and
  it is being fixed. It is the right app.</p>
  <p>When a new version comes out you may have to grant screen recording again, because macOS treats an unsigned
  update as a different app. Annoying, not broken.</p>
</div>
<div class="note">
  <p>Only ever install FrameCast from the link Andrei sends you. Do not download a "FrameCast" from anywhere else.
  There is no public download, and anything claiming to be one is not from us.</p>
</div>
"""

s = sub(s,
 """<h3>Mac</h3>
<div class="note">
  <p>There is no Mac build of FrameCast yet. If you are on a Mac, message Andrei and he will tell you what to use instead. Do not download a "FrameCast" from anywhere else. There is no such thing, and anything claiming to be one is not from us.</p>
</div>""",
 MAC, "setup: mac section")

# ------------------------------------------------------- renumber 6-8
s = sub(s, "<h2>6. What you earn",       "<h2>7. What you earn",        "setup: renumber 6")
s = sub(s, "<h2>7. Proving we are real", "<h2>8. Proving we are real",  "setup: renumber 7")
s = sub(s, "<h2>8. The rules that do not bend", "<h2>9. The rules that do not bend", "setup: renumber 8")

# ------------------------------------- new section 6: the receptionist
REC = """<h2>6. If you sell the AI receptionist</h2>
<p>This product works differently to the website, so the steps after the sale are different too. Do not improvise
them.</p>

<div class="note warn">
  <div class="lab">BEFORE YOU SELL ONE</div>
  <p>Your Frame Empire agreement sets your commission at 50% of the sale price of a website. A monthly subscription
  does not have a single sale price, so there is a short <b>Product Schedule</b> that has to be signed before you sell
  one. If you have not signed it, ask Andrei. Do not sell on a handshake and sort the commission out later.</p>
</div>

<h3>The demo number</h3>
<p>There is one number you give prospects so they can hear it for themselves. It is in the AI Receptionist track.
If it is not filled in there, the product is not ready to sell and you should be selling websites today.</p>

<h3>Payment</h3>
<p>There are two payments and they are separate. The setup fee is paid once. The monthly plan is a subscription that
recurs. Both go through Frame Empire's official links and never through you. You do not take card details, bank
transfers or cash for either, ever.</p>

<h3>After they pay</h3>
<ol>
  <li>Mark it in the CRM straight away: plan, setup fee, start date.</li>
  <li>Book the onboarding call while they are still on the phone. Ten minutes, and it needs to happen within a day or
  two while they are still keen.</li>
  <li>Collect the eleven onboarding answers listed in the AI Receptionist track. All eleven. A half filled form is why
  clients cancel in week three.</li>
  <li>Test it with the client before it answers a single real call. They hear it before their customers do.</li>
</ol>

<h3>If a client has a problem</h3>
<p>Log it and escalate. Do not promise a fix or a timescale yourself, and do not start changing settings. It is
answering someone else's phone to their real customers, so a guess is expensive.</p>

<h2>"""

s = sub(s, "<h2>7. What you earn", REC + "7. What you earn", "setup: insert receptionist section")

io.open(p, "w", encoding="utf-8").write(s)

if FAIL:
    print("FAILURES, nothing written for those:")
    for f in FAIL: print("  !", f)
    sys.exit(1)
print("setup and tools updated cleanly")
