# Training integration: thinking brief

**For a Claude Code session in `frame-empire-crm`. Read this alongside `CLAUDE.md`.**

This is not a build spec. Nothing here has been decided. It is the map of what exists on both sides, the options with their honest costs, the constraints that rule some of them out, and the questions Andrei wants to work through before a line of code is written.

**Do not start implementing.** Work through the decisions first.

---

## 1. What exists on the training side

Seven standalone HTML files, self-contained, no build step, no external dependencies. Currently delivered to contractors by WhatsApp as file attachments.

| File | Size | What it is | Audience |
|---|---:|---|---|
| `FE_Training_Hub.html` | 16 KB | Front door. Routes people through the shared spine then to a product track. | Everyone |
| `FE_Start_Here.html` | 162 KB | Onboarding wizard. Identity, self employment, how pay works, the rules. | Everyone |
| `FE_Caller_Walkthrough.html` | 49 KB | Narrated 14 scene intro with voice and transcript. | Everyone |
| `FE_Setup_And_Tools.html` | 27 KB | FrameCast, softphone, CRM access, payment links, per-team selector (fe / simon / nrc). | Everyone |
| `FE_Training_Portal.html` | 198 KB | The long one. 7 modules: sales foundations, voice and energy, playbook, first no, WhatsApp closing. Has its own quiz engine. | Everyone |
| `FE_Track_Websites.html` | 36 KB | Website product sale. 10 modules, 9 question check. | Website sellers |
| `FE_Track_Receptionist.html` | 47 KB | AI receptionist sale. 13 modules, 10 question check, interactive earnings calculator. | Receptionist sellers |
| | **535 KB** | | |

**Structure:** a shared spine (Hub → Start Here → Walkthrough → Setup and Tools → Training Portal) that is identical whatever someone sells, then one of two product tracks. The split exists because selling a one off website and selling a monthly subscription are genuinely different sales.

**Progress today:** `localStorage`, per browser, per device, invisible to anyone else. The two new tracks store under `fe_track_<web|ai>`; the older files have their own keys.

**Source of truth:** the two tracks and the hub are **generated** by a small Python toolchain, not hand written:

```
build_tracks.py     shared CSS/JS shell, the page() builder, and dict N
                    which holds EVERY price, rate and commission figure
content_web.py      Websites track content
content_ai.py       AI receptionist track content
make.py             builds FE_Training_Hub / FE_Track_Websites / FE_Track_Receptionist
update2/3/4.py      assertion based surgical editors for the four older files
```

Every price in every generated file comes from one dict. Change `N["w_premium"]` and rebuild, and all three files agree. That property is worth protecting, and it is the first thing a careless port would destroy.

---

## 2. What already exists on the CRM side

**This is the part that changes the shape of the problem.** The CRM is not a blank slate for teaching people things. It already has a full guidance system, documented in `CLAUDE.md` under "First time tour, 🎓 Tutorial, contextual tips, dialer guide (2026-09-12)".

- `GUIDE_TOURS` - step lists per role (caller / manager / admin) plus `chat` and `report` mini tours
- Engine: `guideStart` / `guideShow` / `guidePosition` / `guideEnd`, with `.g-blk` blocker, `.g-spot` spotlight, `.g-tip` card, keyboard nav, bottom sheet under 640px
- `guideScheduleAuto` + `guideCanAuto` - runs the role tour once per user per device
- `CTX_TIPS` + `ctxInit/ctxTrigger/ctxShow` - contextual tips that fire the first time someone uses a control (status pill, callback, sale, notes, phrase picker, WhatsApp scripts, Focus Dial, bulk, search, dial mode, bell, and per tab for admin/manager)
- `#tutorialBtn` in the header, the **only** help control in the UI, opening Tips switch / Restart tour / Set up PC dialling
- State in `localStorage` as `fe_guide_<user>` = `{off, done, bridgeOk, bridgeSeen}`
- `GUIDE_V` bumps to replay everything after a big UI change
- Tests in `tests/guide.test.js`

**So there are two teaching systems that do not know about each other.** The CRM teaches *how to drive the CRM*. The training files teach *how to do the job*. That distinction is real and probably worth keeping, but the seam between them is where this work lives.

Andrei's stated brief for the existing system was: **no `?` buttons anywhere, one button to reactivate the tutorial.** Any proposal that scatters help affordances through the UI contradicts a decision he has already made and defended.

---

## 3. What "integration" might actually be for

Worth agreeing on before choosing an architecture, because the options differ enormously depending on which of these matter.

1. **Findability.** Callers currently hunt through WhatsApp for an attachment someone sent three weeks ago. A Training tab solves this and nothing else, and might be 80% of the value.
2. **Completion visibility.** Right now nobody can answer "has Michaela done the Start Here?" Progress lives in her browser.
3. **Gating.** No leads assigned until Start Here is done and your track's knowledge check is passed. Powerful, and also the thing most likely to annoy people if it misfires.
4. **Contextual recall.** A caller marks a lead "Not Interested" for the fourth time today. Should the objections module surface right there? The `CTX_TIPS` machinery already does exactly this shape of thing.
5. **Product assignment.** A caller selling websites only should probably never see the receptionist track. The CRM already knows who each caller is and who they report to.
6. **Feedback loop.** `CLAUDE.md` describes an objection logging loop: callers log verbatim objections, Andrei works out the best reply, it feeds back to the team. Today that last step is manual. The training files are where those answers belong.

**Question for Andrei: rank these.** The honest guess is 1 and 2 carry most of the value for a nine person team, and 3 is a trap until the roster and the process are stable. But it is his call.

---

## 4. Four architectures

### Option A: Link out
A Training tab in the CRM linking to the seven files served at `/training/*.html` on the existing Netlify site.

- **Effort:** half a day
- **Gets you:** findability, one URL, always current, works on mobile
- **Does not get you:** any visibility into who has done what
- **Risk:** near zero. `index.html` gains a tab and seven links.
- **Generator:** untouched, still the source of truth

### Option B: Link out plus a completion beacon
Option A, plus each training page posts module completions to a Netlify function, which writes to a new `training_progress` table. The CRM shows a progress column per caller.

- **Effort:** one to two days
- **Gets you:** everything in A, plus manager visibility, plus the raw material for gating later
- **Costs:** migration `017_training_progress.sql`, RLS policies, new ops in `read-action.mjs` and `write-action.mjs`, a ~30 line script appended to each training page, and a way for a training page opened from the CRM to know who the viewer is
- **Generator:** the beacon goes into `build_tracks.py`'s shared JS, so generated files get it automatically. The four hand maintained files need it added via the existing `update*.py` assertion pattern.

### Option C: Embed in an iframe
A Training tab that iframes the files inside the CRM shell.

- **Effort:** one to two days, plus debugging
- **Gets you:** feels native, one login
- **Costs:** still needs B's beacon for tracking, so it is B plus iframe problems. The PWA service worker (`sw.js`) and iframe caching interact badly. Double scroll containers on phones. The narrated Walkthrough needs audio autoplay permission inside a frame.
- **Verdict:** probably the worst ratio here. It buys presentation, not capability.

### Option D: Port the content into `index.html` as native modules
Rebuild the training as CRM modules reusing `GUIDE_TOURS` and `CTX_TIPS`, progress in Supabase, fully gateable and contextual.

- **Effort:** weeks
- **Gets you:** everything, done properly
- **Costs:** see the constraints below, which are severe
- **Verdict:** not as a first step. Possibly later, and only for the specific parts that genuinely need to live in the app.

---

## 5. Hard constraints

These are facts about the codebase, not opinions. They should shape the choice.

**`public/index.html` is 872,938 bytes.** The training is 534,538 bytes. A full port takes the CRM to roughly 1.4 MB in one file. `CLAUDE.md` already records that the in-app browser and a local `http.server` **truncate the page** during testing, which is why Playwright MCP against `file:///` with a `mock_session.js` script tag is the documented workflow. Making that file 60% bigger makes an already awkward situation materially worse. **This is the single strongest argument against Option D.**

**The generator must stay the source of truth.** Prices, commission rates and the 12 month MRR term all live in one Python dict. Hand porting that content into `index.html` means the next price change has to be made twice, and the two will drift. If any content moves in-app, it must be *generated into* `index.html` by a build step, not copy pasted.

**The inline drift detector.** `src/lib/` holds canonical tested helpers, and `public/index.html` carries hand copies. `tests/readProtection.test.js` fails the build if they diverge. Any new pure helper (for example progress percentage maths) must exist in both, with the inline copy pointing at its line range, matching the existing convention.

**All reads and writes go through Netlify Functions.** RLS denies anon SELECT/INSERT/UPDATE on 10 tables. The browser never talks to Supabase directly for those. A `training_progress` table means: migration, RLS policies, a new op in `read-action.mjs`, a new op in `write-action.mjs`, and scope gating so a caller can only write their own rows. Follow the pattern in `docs/READ_PROTECTION_PLAN.md` and `docs/WRITE_PROTECTION_PLAN.md`.

**`MGR_CALLERS` is duplicated** between `public/index.html` and `netlify/functions/_shared.mjs`, with a drift detector enforcing equality. Anything keyed per caller touches both.

**Bumping `GUIDE_V`** replays tours and tips for every user. If training work touches the guide system, that is a deliberate decision with a visible effect on nine people.

**No em dashes.** Anywhere. Code, docs, UI strings.

---

## 6. Two prerequisites that are not code

**The CRM roster is badly out of date.** `CLAUDE.md` says "Current team (1 caller as of 2026-05-19)" with only Adefeso Ayodeji active and Robinson's team empty. Reality as of mid September is nine contracted people: Simon Waterton (head manager, coach, closer), Kieron Booth, Ayodeji Adefeso, Debray Rymaa, Michaela Renzi, Cseh Nandor, Ifeoma Judith Nweze, Confidence Jude, Joe Burns, plus four NRC callers under Robinson. Assigning training to callers who do not exist in the CRM is not possible. **Fix the roster first, or at minimum design around the fact that it is stale.**

**The receptionist track is deliberately gated and the gate is not open.** Module 00 blocks selling until a demo number is filled in, and it currently reads `[DEMO NUMBER NOT SET]` in `build_tracks.py`. If the CRM assigns tracks by product, the receptionist track should stay hidden until that number exists. Do not build an assignment system that can hand someone a track they are not allowed to act on.

---

## 7. Questions to work through with Andrei

1. Which of the six purposes in section 3 actually matter? If it is only findability, Option A ships this week and the rest is over engineering.
2. Should completion be **visible** (a manager can see it) or **enforcing** (no leads without it)? These are very different amounts of work and very different amounts of trouble.
3. Who assigns a product track: does Andrei set it per caller in the CRM, or does the caller choose?
4. Should the CRM's existing tour and the job training stay separate systems, or converge? They teach different things, and the "one help button" rule suggests they should at least share one entry point.
5. Does the objection logging loop feed the training content, and if so, how does an objection logged in the CRM become a line in `content_web.py`?
6. Where do the files live: served from the CRM's Netlify site under `/training/`, or somewhere else? This decides whether a caller needs to be logged in to read them, and whether the beacon can identify them.
7. Is any of this worth doing before the roster is current and the receptionist product is real?

---

## 8. What not to do

- Do not start by porting content into `index.html`. See section 5.
- Do not copy training content out of the Python files by hand. The generator is the source of truth.
- Do not add `?` buttons or scatter help icons. Andrei has an explicit standing decision: one help control.
- Do not build gating before the roster is current. Locking nine people out of leads on stale data is a bad first impression of the feature.
- Do not write to Supabase from the browser directly. Everything goes through the Functions.
- Do not assume the training files are static. They are build outputs, and they will be rebuilt when prices change.

---

## 9. What is in this folder

```
docs/training-source/
├── TRAINING_INTEGRATION_BRIEF.md    this file
├── build_tracks.py                  shared shell + the N dict (all prices)
├── content_web.py                   Websites track content
├── content_ai.py                    AI receptionist track content
├── make.py                          builds hub + both tracks
├── update2.py, update3.py, update4.py   surgical editors for the older four files
└── html/                            the seven built files
```

Rebuild with `python3 make.py` from the folder containing the `.py` files.

---

*Frame Empire Ltd, company number 16163944. Prepared 15 September 2026.*
