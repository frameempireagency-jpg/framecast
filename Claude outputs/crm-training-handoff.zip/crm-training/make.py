#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the hub and the two product tracks."""
import io, html
from build_tracks import N, CSS, JS, gbp, pence, page
import content_web, content_ai

OUT = {}

# =====================================================================
#  THE TWO TRACKS
# =====================================================================
OUT["FE_Track_Websites.html"] = page(
    "Frame Empire | Selling Websites",
    "web",
    "TRACK ONE",
    "Selling websites",
    "Everything specific to the website product: who to ring, what to say, the three prices and the rules that keep "
    "them lawful, the five objections you will hear every day, and how to close without ever touching a client's money.",
    content_web.mods(),
)

OUT["FE_Track_Receptionist.html"] = page(
    "Frame Empire | Selling the AI Receptionist",
    "ai",
    "TRACK TWO",
    "Selling the AI receptionist",
    "A different product and a different sale. This one is discovery-led, it is sold on a monthly plan, and it is the "
    "one where being honest about the limits is what wins the deal. Read section 00 before anything else.",
    content_ai.mods(),
)

# =====================================================================
#  THE HUB
# =====================================================================
def card(href, num, title, sub, body, badge=""):
    b = f'<span style="margin-left:auto;flex:0 0 auto;font-size:11px;letter-spacing:.12em;color:var(--signal);border:1px solid rgba(37,211,102,.35);border-radius:99px;padding:3px 10px">{badge}</span>' if badge else ""
    return (f'<a class="card" href="{href}">'
            f'<span class="num">{num}</span>'
            f'<span class="ct"><b>{title}</b><em>{sub}</em>'
            f'<span class="cb">{body}</span></span>{b}</a>')

HUB_EXTRA = r"""
.card{display:flex;gap:14px;align-items:flex-start;text-decoration:none;color:inherit;
  border:1px solid var(--line);border-radius:14px;background:var(--panel);padding:17px 19px;margin:0 0 10px;transition:.15s}
.card:hover{border-color:var(--violet-lift);background:var(--panel-2)}
.card:focus-visible{outline:2px solid var(--signal);outline-offset:2px}
.card .ct{flex:1;min-width:0}
.card .ct b{display:block;font-family:var(--display);font-weight:600;font-size:17px;color:var(--paper);line-height:1.3}
.card .ct em{display:block;font-style:normal;font-size:12.5px;color:var(--muted);margin-top:2px}
.card .cb{display:block;font-size:14px;color:#C9B7E4;margin-top:9px;line-height:1.6}
.card.big{border-color:var(--violet-lift);background:linear-gradient(135deg,rgba(82,31,136,.22),var(--panel))}
.stage{margin:38px 0 14px}
.stage b{font-family:var(--display);font-weight:600;font-size:13px;letter-spacing:.18em;text-transform:uppercase;color:var(--signal)}
.stage p{font-size:14px;color:var(--muted);margin:5px 0 0;max-width:62ch}
.rule{height:1px;background:var(--line);margin:6px 0 16px}
"""

hub = []
hub.append('<!DOCTYPE html><html lang="en-GB"><head>')
hub.append('<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">')
hub.append('<title>Frame Empire | Training Hub</title>')
hub.append('<style>' + CSS + HUB_EXTRA + '</style></head><body data-track="hub"><div class="shell">')

hub.append('<div class="top"><div class="brandrow"><b>FRAME EMPIRE</b>'
           '<span class="pill">TRAINING HUB</span>'
           '<span style="margin-left:auto">Start at the top and work down</span></div></div>')

hub.append('<header class="hero"><p class="kick">EVERYTHING IN ORDER</p>'
           '<h1>Start here, then pick what you sell</h1>'
           '<p class="lede">The first three are the same for everyone, whatever product you end up selling. '
           'Do them in order and do not skip. After that you choose a track, and you can do both.</p></header>')

hub.append('<div class="stage"><b>Stage one &nbsp;&middot;&nbsp; Everyone, in this order</b>'
           '<p>This is the part that does not change. Who you are, how you are paid, the tools, and how to '
           'hold a call. None of it is product specific.</p></div><div class="rule"></div>')

hub.append(card("FE_Start_Here.html", "01", "Start Here",
    "Your first hour &middot; about 20 minutes",
    "Who you are working with, how self employment works here, how and when you get paid, and the few rules that "
    "never bend. Finish this before you do anything else."))

hub.append(card("FE_Caller_Walkthrough.html", "02", "Caller Walkthrough",
    "Watch and listen &middot; about 15 minutes",
    "The narrated introduction. What this job actually is, what we sell, and what you earn. Open it on a laptop if "
    "you can, and turn the sound on."))

hub.append(card("FE_Setup_And_Tools.html", "03", "Setup and Tools",
    "Get working &middot; about 30 minutes",
    "FrameCast, your phone system, the CRM, your Frame Empire email and the payment links. Frame Empire pays for all "
    "of it. You are never asked to buy, top up or reimburse anything."))

hub.append(card("FE_Training_Portal.html", "04", "Caller Training Portal",
    "The foundations &middot; work through it over your first week",
    "The long one. Sales foundations, voice and energy, the playbook, handling the first no, and closing on WhatsApp. "
    "These skills carry across both products, so it is worth the time."))

hub.append('<div class="stage"><b>Stage two &nbsp;&middot;&nbsp; Pick the product you are selling</b>'
           '<p>These two are genuinely different sales. Do not read the other one until you have made money with '
           'the first. Trying to learn both in week one is the most common way people end up selling neither.</p>'
           '</div><div class="rule"></div>')

hub.append(f'''<a class="card big" href="FE_Track_Websites.html">
<span class="num">W</span><span class="ct"><b>Track one: Selling websites</b>
<em>Start here unless you have been told otherwise</em>
<span class="cb">One product, three prices, paid once and owned forever. We build it first and they only pay if they
like it, which is the strongest offer you will ever have on a phone. Your base commission is
{N['base_pct']}% of the sale price, so {gbp(N['w_premium_comm'])} on a {gbp(N['w_premium'])} sale.</span></span>
<span style="margin-left:auto;flex:0 0 auto;font-size:11px;letter-spacing:.12em;color:var(--signal);border:1px solid rgba(37,211,102,.35);border-radius:99px;padding:3px 10px">LIVE</span></a>''')

hub.append(f'''<a class="card big" href="FE_Track_Receptionist.html">
<span class="num">R</span><span class="ct"><b>Track two: Selling the AI receptionist</b>
<em>Read section 00 before you do anything else</em>
<span class="cb">A monthly service that answers their phone when they cannot. {gbp(N['r_setup'])} to set up and from
{gbp(N['r_t1_price'])} a month. You earn {N['setup_pct']}% of the setup fee and {N['mrr_pct']}% of the monthly for
{N['mrr_months']} months, so it starts smaller and then it keeps arriving. This one needs a signed Product Schedule
before you sell it.</span></span>
<span style="margin-left:auto;flex:0 0 auto;font-size:11px;letter-spacing:.12em;color:var(--warn);border:1px solid var(--warn-line);border-radius:99px;padding:3px 10px">CHECK FIRST</span></a>''')

hub.append('<div class="stage"><b>Stage three &nbsp;&middot;&nbsp; Keep these open while you work</b>'
           '<p>Not things to read once. Things to have open in a tab.</p></div><div class="rule"></div>')

hub.append('<div class="note good"><b>The four rules that apply to everything</b>'
           '<ol style="margin:8px 0 0"><li>You never handle client money. Every payment goes to Frame Empire.</li>'
           '<li>You are never asked to pay for anything. Not a subscription, not calling credit, not software. If '
           'someone asks you to, it is not Frame Empire.</li>'
           '<li>You never make a claim you cannot back up. Not about price, timing, results or what is included.</li>'
           '<li>One honest response to the first no, then you thank them and go.</li></ol></div>')

hub.append('<div class="foot">Frame Empire Ltd, registered in England and Wales, company number 16163944. '
           'This material is for Frame Empire contractors. Do not forward it to anyone outside the team.</div>')
hub.append('</div></body></html>')

OUT["FE_Training_Hub.html"] = "\n".join(hub)

# =====================================================================
for name, content in OUT.items():
    io.open(name, "w", encoding="utf-8").write(content)
    print(f"wrote {name}  ({len(content):,} bytes)")
