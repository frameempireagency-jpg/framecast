#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fix the own-vs-rent contradiction.

The portal currently teaches callers that a £99/month subscription where you
own nothing is a rip-off. Frame Empire is about to sell a £99/month
subscription where you own nothing. Left as is, a caller selling both sounds
like a hypocrite, and a prospect who has spoken to two of our callers notices.

The honest distinction is own the asset, rent the service. Nobody buys a
receptionist outright either.
"""
import io, sys

FAIL = []
def sub(s, old, new, label, count=1):
    n = s.count(old)
    if n != count:
        FAIL.append(f"{label}: expected {count}, found {n}")
        return s
    return s.replace(old, new)

# =====================================================================
p = "FE_Training_Portal.html"
s = io.open(p, encoding="utf-8").read()

OLD = ('<h3 class="bh">The Key Talking Point  -  Own vs Rent</h3><ul>'
       '<li>Pay-monthly: After 2 years at £99/month = £2,376 spent and you STILL OWN NOTHING. '
       'Cancel = lose the website entirely.</li>'
       '<li>Frame Empire: one payment, from £400 to £650. You own it forever. No monthly fees. '
       'No lock-in.</li>'
       '<li>Frame Empire is cheaper than 2 years of any subscription  -  and the client actually owns the '
       'result.</li>'
       '<li>On calls: "With other services, you\'re renting your website. With us, you own it outright. '
       'No monthly fee, no contract."</li></ul>')

NEW = ('<h3 class="bh">The Key Talking Point  -  Own the asset, rent the service</h3><ul>'
       '<li>A <b>pay-monthly website</b>: after 2 years at £99/month that is £2,376 spent and the client '
       'still owns nothing. If they cancel, the website disappears.</li>'
       '<li>Frame Empire: one payment, from £400 to £650. They own it forever. No monthly fee, no '
       'lock-in, and cheaper than two years of any website subscription.</li>'
       '<li>On calls: "With other services you are renting your website. With us you own it outright."</li></ul>'
       '<div class="box" style="border-left:5px solid #521F88;background:#EDE6F5">'
       '<p><b style="color:#521F88">Say "website" in that argument, every time.</b> Frame Empire also sells an AI '
       'receptionist on a monthly plan, and a caller who has just finished telling somebody that monthly pricing is '
       'a rip-off cannot then sell them a monthly plan. The distinction is real and it is worth learning properly:</p>'
       '<p><b>You buy a thing. You rent a service.</b> A website is a thing the client should own outright, like a '
       'van or a shopfront. Somebody answering the phone at seven at night is a service, and nobody buys a '
       'receptionist outright either. Renting a thing is a bad deal. Renting a service is the only way a service '
       'has ever been sold.</p>'
       '<p>If a prospect ever throws it back at you  -  "your mate told me monthly was a con"  -  that sentence is '
       'the answer, and it makes us look consistent rather than caught out.</p></div>')

s = sub(s, OLD, NEW, "portal: own vs rent")
io.open(p, "w", encoding="utf-8").write(s)
print("portal own-vs-rent fixed")

if FAIL:
    print("FAILURES:")
    for f in FAIL: print("  !", f)
    sys.exit(1)
