#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Second surgical pass on the three original training files, for the
two-product model. Assertion based: if a target string is not found
exactly once, nothing is written and the script exits non-zero.
"""
import io, sys

FAIL = []

def sub(s, old, new, label, count=1):
    n = s.count(old)
    if n != count:
        FAIL.append(f"{label}: expected {count}, found {n}")
        return s
    return s.replace(old, new)


# =====================================================================
#  1. CALLER WALKTHROUGH
#     Keep it as the shared "what this job is" piece. Add one scene
#     that introduces the second product. Do not teach selling here.
# =====================================================================
p = "FE_Caller_Walkthrough.html"
s = io.open(p, encoding="utf-8").read()

NEW_SCENE = (
 '{"id": "both", "chapter": "Two products", "secs": 13, "visual": "both", "enter": "cascade", '
 '"kicker": "AND ONE MORE THING", "title": "There are two things to sell", '
 '"body": "The website is paid once. The AI receptionist answers a business owner\'s phone when they cannot, and it '
 'is paid monthly. Most people start with websites and add the second one later. You never have to sell both.", '
 '"narrate": "There are actually two things you can sell. The website is paid once. The A I receptionist answers a '
 'business owner\'s phone when they cannot get to it, and that one is paid monthly. Most people start with websites '
 'and add the second one later. You never have to sell both."}, ')

s = sub(s, '{"id": "preview"', NEW_SCENE + '{"id": "preview"', "walkthrough: insert two-product scene")

# the data for the new visual
s = sub(s,
 'TIERS=[["Premium Business Website","\\u00a3650","Always open here"],',
 'BOTH=[["Websites","Built first, paid once, owned forever","\\u00a3400 to \\u00a3650"],'
 '["AI receptionist","Answers their phone when they cannot","from \\u00a399 a month"]], '
 'TIERS=[["Premium Business Website","\\u00a3650","Always open here"],',
 "walkthrough: BOTH array")

# the new visual case, modelled on the existing tiers case
s = sub(s,
 "    case 'tiers':",
 """    case 'both':
      return '<div class="chain">'+BOTH.map(function(t,k){
        return '<div class="link" style="animation-delay:'+(k*.26)+'s"><i class="dot"></i><span style="flex:1"><b style="color:#efe9f8;font-weight:600">'+esc(t[0])+'</b><em style="display:block;font-style:normal;font-size:12.5px;color:#9C8FB0;margin-top:3px">'+esc(t[1])+'</em></span><b style="color:var(--signal);font-variant-numeric:tabular-nums;font-size:15px;white-space:nowrap">'+esc(t[2])+'</b></div>';}).join('')+'</div>';
    case 'tiers':""",
 "walkthrough: both visual case")

# point people at the hub when they finish
s = sub(s,
 '  <p class="foot"><b style="color:#c9b7e4">Open this file in a web browser, on a laptop if you can.</b>',
 '  <p class="foot"><b style="color:#c9b7e4">When you have finished this, open FE_Training_Hub.html '
 'and carry on from step three.</b><br><br>'
 '<b style="color:#c9b7e4">Open this file in a web browser, on a laptop if you can.</b>',
 "walkthrough: hub pointer")

io.open(p, "w", encoding="utf-8").write(s)
print("walkthrough updated")


# =====================================================================
#  2. START HERE
#     Stays a single shared file. It is identity, contract, pay and
#     rules, which are identical whatever you sell. Only the ending
#     changes, so that it routes to the hub instead of dead ending.
# =====================================================================
p = "FE_Start_Here.html"
s = io.open(p, encoding="utf-8").read()

s = sub(s,
 '"tip": "You earn 50% of every completed sale as your base rate, paid within 7 days of the client\'s payment clearing.'
 ' On a £650 sale that is £325.',
 '"tip": "You earn 50% of every completed website sale as your base rate, paid within 7 days of the client\'s payment '
 'clearing. On a £650 sale that is £325. The AI receptionist is paid differently because it is a monthly '
 'service, and it has its own signed schedule. Your track explains it.',
 "start here: commission tip mentions second product")

io.open(p, "w", encoding="utf-8").write(s)
print("start here updated")


# =====================================================================
#  3. TRAINING PORTAL
#     Stays the shared foundation. Module 3 keeps the website detail
#     but stops claiming to be the whole picture.
# =====================================================================
p = "FE_Training_Portal.html"
s = io.open(p, encoding="utf-8").read()

s = sub(s,
 '<section class="module" id="m3">',
 '<section class="module" id="m3">'
 '<div style="border:1.5px solid #521F88;background:#EDE6F5;border-radius:12px;padding:14px 18px;margin:0 0 18px">'
 '<b style="color:#521F88;letter-spacing:1.5px;font-size:11.5px">FRAME EMPIRE NOW SELLS TWO THINGS</b>'
 '<p style="margin:6px 0 0;font-size:14.5px">This module covers the website, which is what most callers sell. '
 'There is a second product, an AI receptionist sold on a monthly plan, and it has its own track. '
 'Open <b>FE_Training_Hub.html</b> and pick the track you have been put on. '
 'Everything else in this portal applies to both.</p></div>',
 "portal: two-product banner on module 3")

io.open(p, "w", encoding="utf-8").write(s)
print("portal updated")


print()
if FAIL:
    print("FAILURES, nothing was written for those:")
    for f in FAIL:
        print("  !", f)
    sys.exit(1)
print("all replacements applied cleanly")
