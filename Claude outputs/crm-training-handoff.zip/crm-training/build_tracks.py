#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Frame Empire: build the two product sales tracks plus the hub.

One source of truth for every number. Change it here, rebuild, and every
page agrees. Nothing is hardcoded twice.
"""
import io, json, html, sys

# =====================================================================
#  THE NUMBERS. Single source of truth.
# =====================================================================
N = {
    # Websites
    "w_premium": 650, "w_special": 500, "w_final": 400,
    "w_preview_hours": "24 to 48 hours",

    # Receptionist
    "r_setup": 299,
    "r_t1_name": "Reception",      "r_t1_price": 99,  "r_t1_min": 250,  "r_t1_over": 0.35,
    "r_t2_name": "Reception Plus", "r_t2_price": 199, "r_t2_min": 600,  "r_t2_over": 0.30,
    "r_t3_name": "Reception Pro",  "r_t3_price": 349, "r_t3_min": 1500, "r_t3_over": 0.25,

    # Commission
    "base_pct": 50,
    "setup_pct": 50,
    "mrr_pct": 10,
    "mrr_months": 12,

    # Placeholders the founder must fill before rollout
    "demo_number": "[DEMO NUMBER NOT SET]",
    "stripe_note": "Links live in Setup and Tools",
}

def gbp(v):
    return f"£{v:,.2f}" if v % 1 else f"£{int(v):,}"

def pence(v):
    return f"£{v:.2f}"

# Derived, never typed by hand
N["w_premium_comm"] = N["w_premium"] * N["base_pct"] / 100
N["w_special_comm"] = N["w_special"] * N["base_pct"] / 100
N["w_final_comm"]   = N["w_final"]   * N["base_pct"] / 100
N["r_setup_comm"]   = N["r_setup"]   * N["setup_pct"] / 100
for t in (1, 2, 3):
    N[f"r_t{t}_comm"] = N[f"r_t{t}_price"] * N["mrr_pct"] / 100
    N[f"r_t{t}_total"] = N["r_setup_comm"] + N[f"r_t{t}_comm"] * N["mrr_months"]

# =====================================================================
#  SHARED SHELL
# =====================================================================
CSS = r"""
:root{
  --ink:#0C0A0C; --violet:#521F88; --violet-lift:#6B2FB0; --violet-deep:#2E1049;
  --signal:#25D366; --paper:#EFE9F8; --muted:#9C8FB0; --line:#241a30; --panel:#150E1D;
  --panel-2:#1B1226;
  --warn:#E0A64B; --warn-bg:rgba(224,166,75,.09); --warn-line:rgba(224,166,75,.35);
  --stop:#E0566B; --stop-bg:rgba(224,86,107,.09); --stop-line:rgba(224,86,107,.34);
  --display:'Segoe UI Semibold','Helvetica Neue',system-ui,-apple-system,sans-serif;
  --body:system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',sans-serif;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
html,body{margin:0;padding:0;overflow-x:hidden;background:var(--ink);color:var(--paper);
  font-family:var(--body);-webkit-font-smoothing:antialiased;font-size:16px;line-height:1.65}
body::before{content:"";position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:linear-gradient(rgba(82,31,136,.06) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(82,31,136,.06) 1px,transparent 1px);
  background-size:64px 64px}
.shell{position:relative;z-index:1;max-width:880px;margin:0 auto;padding:0 20px 90px}
a{color:var(--signal)}
img{max-width:100%}

/* top bar */
.top{position:sticky;top:0;z-index:40;background:rgba(12,10,12,.96);backdrop-filter:blur(10px);
  border-bottom:1px solid var(--line);margin:0 -20px;padding:13px 20px}
.brandrow{display:flex;align-items:baseline;gap:10px;font-size:12px;color:var(--muted);flex-wrap:wrap}
.brandrow b{color:var(--paper);letter-spacing:.18em;font-size:11px;font-weight:700}
.brandrow .pill{border:1px solid var(--line);border-radius:99px;padding:2px 10px;font-size:11px}
.prog{height:3px;background:var(--line);border-radius:99px;margin-top:11px;overflow:hidden}
.prog i{display:block;height:100%;width:0;background:var(--signal);transition:width .35s ease}

/* hero */
.hero{padding:54px 0 30px;border-bottom:1px solid var(--line)}
.kick{font-size:11px;letter-spacing:.22em;color:var(--signal);font-weight:700;margin:0 0 12px}
h1{font-family:var(--display);font-weight:600;font-size:clamp(30px,6vw,46px);line-height:1.1;margin:0 0 14px;letter-spacing:-.01em}
.lede{font-size:clamp(16px,2.4vw,18.5px);color:#C9B7E4;margin:0;max-width:60ch}

/* module */
details.mod{border:1px solid var(--line);border-radius:16px;background:var(--panel);margin:14px 0;overflow:hidden}
details.mod[open]{border-color:var(--violet-lift)}
summary{list-style:none;cursor:pointer;padding:18px 20px;display:flex;align-items:center;gap:14px}
summary::-webkit-details-marker{display:none}
summary:focus-visible{outline:2px solid var(--signal);outline-offset:-2px}
.num{flex:0 0 34px;height:34px;border-radius:10px;background:var(--violet-deep);color:#C9B7E4;
  display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;
  font-variant-numeric:tabular-nums;border:1px solid var(--line)}
details.mod[open] .num{background:var(--violet);color:#fff;border-color:var(--violet-lift)}
.mod.done .num{background:rgba(37,211,102,.14);color:var(--signal);border-color:rgba(37,211,102,.4)}
.stitle{flex:1;min-width:0}
.stitle b{display:block;font-family:var(--display);font-weight:600;font-size:17px;color:var(--paper);line-height:1.3}
.stitle em{display:block;font-style:normal;font-size:13px;color:var(--muted);margin-top:2px}
.chev{flex:0 0 auto;color:var(--muted);font-size:13px;transition:transform .2s}
details.mod[open] .chev{transform:rotate(90deg)}
.body{padding:2px 20px 24px;border-top:1px solid var(--line)}
.body>*:first-child{margin-top:18px}

h2{font-family:var(--display);font-weight:600;font-size:18px;margin:26px 0 8px;color:#DCCBF2}
h2:first-child{margin-top:0}
p{margin:0 0 12px}
ul,ol{margin:0 0 14px;padding-left:22px}
li{margin:0 0 7px}
strong{color:#fff;font-weight:600}

/* callouts */
.note{border-radius:12px;padding:14px 16px;margin:16px 0;font-size:14.5px;border:1px solid}
.note b{display:block;margin-bottom:4px;font-size:12px;letter-spacing:.13em;text-transform:uppercase}
.note.law{background:var(--warn-bg);border-color:var(--warn-line);color:#F0DCBC}
.note.law b{color:var(--warn)}
.note.never{background:var(--stop-bg);border-color:var(--stop-line);color:#F5CDD4}
.note.never b{color:var(--stop)}
.note.good{background:rgba(37,211,102,.07);border-color:rgba(37,211,102,.3);color:#CDEEDA}
.note.good b{color:var(--signal)}
.note.gate{background:rgba(82,31,136,.16);border-color:var(--violet-lift);color:#DCCBF2}
.note.gate b{color:#C9B7E4}

/* script lines */
.say{border-left:3px solid var(--signal);background:var(--panel-2);border-radius:0 10px 10px 0;
  padding:13px 16px;margin:12px 0;font-size:15.5px;color:#fff}
.say:before{content:"SAY";display:block;font-size:10px;letter-spacing:.2em;color:var(--signal);margin-bottom:5px;font-weight:700}
.dont{border-left:3px solid var(--stop);background:rgba(224,86,107,.06);border-radius:0 10px 10px 0;
  padding:13px 16px;margin:12px 0;font-size:15.5px;color:#F5CDD4}
.dont:before{content:"NEVER SAY";display:block;font-size:10px;letter-spacing:.2em;color:var(--stop);margin-bottom:5px;font-weight:700}

/* tables */
.tw{overflow-x:auto;margin:16px 0;border:1px solid var(--line);border-radius:12px}
table{border-collapse:collapse;width:100%;min-width:440px;font-size:14.5px}
th,td{padding:11px 14px;text-align:left;border-bottom:1px solid var(--line)}
th{background:var(--violet-deep);color:#C9B7E4;font-size:11.5px;letter-spacing:.1em;text-transform:uppercase;font-weight:700}
tr:last-child td{border-bottom:none}
td.n{font-variant-numeric:tabular-nums;white-space:nowrap;color:#fff;font-weight:600}

/* objection cards */
.obj{border:1px solid var(--line);border-radius:12px;background:var(--panel-2);padding:16px 18px;margin:12px 0}
.obj .they{font-size:15.5px;color:#fff;font-weight:600;margin:0 0 10px}
.obj .they:before{content:"\201C"}
.obj .they:after{content:"\201D"}
.obj p:last-child{margin-bottom:0}

/* tiers */
.tiers{display:grid;gap:10px;margin:16px 0}
.tier{border:1px solid var(--line);border-radius:12px;background:var(--panel-2);padding:15px 17px}
.tier.lead{border-color:var(--signal)}
.tier .r1{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap}
.tier .nm{font-family:var(--display);font-weight:600;font-size:16px;color:#fff}
.tier .pr{font-variant-numeric:tabular-nums;font-size:21px;font-weight:700;color:var(--signal)}
.tier .sub{font-size:13px;color:var(--muted);margin-top:5px}

/* calculator */
.calc{border:1px solid var(--violet-lift);border-radius:14px;background:var(--panel-2);padding:18px;margin:18px 0}
.calc label{display:block;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin:0 0 7px;font-weight:700}
.calc input[type=range]{width:100%;accent-color:var(--signal);margin:0 0 4px;height:26px}
.calc .row{display:flex;gap:14px;flex-wrap:wrap;margin-top:14px}
.calc .cell{flex:1 1 140px;border:1px solid var(--line);border-radius:10px;padding:11px 13px;background:var(--panel)}
.calc .cell span{display:block;font-size:11px;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)}
.calc .cell b{display:block;font-size:22px;font-variant-numeric:tabular-nums;color:var(--signal);margin-top:3px;font-weight:700}
.calc .cap{font-size:13px;color:var(--muted);margin:13px 0 0}
.bars{display:flex;align-items:flex-end;gap:5px;height:96px;margin:16px 0 6px}
.bars i{flex:1;background:linear-gradient(180deg,var(--violet-lift),var(--violet));border-radius:3px 3px 0 0;min-height:2px;transition:height .3s}
.bars i.on{background:linear-gradient(180deg,var(--signal),#0f8f42)}
.barcap{display:flex;justify-content:space-between;font-size:11px;color:var(--muted)}

/* quiz */
.quiz{border:1px solid var(--violet-lift);border-radius:14px;background:var(--panel-2);padding:18px;margin:18px 0}
.q{margin:0 0 18px;padding:0 0 18px;border-bottom:1px solid var(--line)}
.q:last-child{border:none;padding-bottom:0;margin-bottom:0}
.q>p{font-weight:600;color:#fff;margin:0 0 10px}
.opt{display:block;width:100%;text-align:left;background:var(--panel);border:1px solid var(--line);
  color:var(--paper);border-radius:10px;padding:10px 13px;margin:0 0 7px;font:inherit;font-size:14.5px;cursor:pointer;transition:.15s}
.opt:hover:not(:disabled){border-color:var(--violet-lift)}
.opt:focus-visible{outline:2px solid var(--signal);outline-offset:2px}
.opt.right{border-color:var(--signal);background:rgba(37,211,102,.12);color:#CDEEDA}
.opt.wrong{border-color:var(--stop);background:rgba(224,86,107,.1);color:#F5CDD4}
.opt:disabled{cursor:default}
.fb{font-size:14px;color:#C9B7E4;margin:8px 0 0;display:none}
.fb.show{display:block}

/* checklist */
.chk{list-style:none;padding:0;margin:14px 0}
.chk li{display:flex;gap:11px;align-items:flex-start;border:1px solid var(--line);border-radius:10px;
  background:var(--panel-2);padding:11px 14px;margin:0 0 7px;font-size:14.5px}
.chk li:before{content:"";flex:0 0 16px;height:16px;margin-top:3px;border:1.5px solid var(--violet-lift);border-radius:4px}

/* nav footer */
.foot{border-top:1px solid var(--line);margin-top:44px;padding-top:22px;font-size:13px;color:var(--muted)}
.foot a{color:#C9B7E4}
.backlink{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);border-radius:99px;
  padding:8px 15px;color:#C9B7E4;text-decoration:none;font-size:13.5px;margin-top:6px}
.backlink:hover{border-color:var(--violet-lift)}

@media (max-width:560px){
  .shell{padding:0 16px 70px}
  .top{margin:0 -16px;padding:12px 16px}
  summary{padding:15px 15px;gap:11px}
  .body{padding:2px 15px 20px}
  .hero{padding:36px 0 24px}
}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}
  html{scroll-behavior:auto}}
@media print{.top{position:static}details.mod{break-inside:avoid}details.mod>.body{display:block!important}}
"""

JS = r"""
(function(){
  var mods=[].slice.call(document.querySelectorAll('details.mod'));
  var bar=document.getElementById('pbar');
  var KEY='fe_track_'+(document.body.dataset.track||'x');
  var seen={};
  try{seen=JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){seen={}}
  function paint(){
    var n=0;
    mods.forEach(function(m,i){
      if(seen[i]){m.classList.add('done');n++}
    });
    if(bar)bar.style.width=(mods.length?Math.round(n/mods.length*100):0)+'%';
  }
  mods.forEach(function(m,i){
    m.addEventListener('toggle',function(){
      if(m.open){
        seen[i]=1;
        try{localStorage.setItem(KEY,JSON.stringify(seen))}catch(e){}
        paint();
      }
    });
  });
  paint();

  // quiz
  [].slice.call(document.querySelectorAll('.q')).forEach(function(q){
    var ans=parseInt(q.dataset.ans,10);
    var opts=[].slice.call(q.querySelectorAll('.opt'));
    var fb=q.querySelector('.fb');
    opts.forEach(function(o,i){
      o.addEventListener('click',function(){
        opts.forEach(function(x){x.disabled=true});
        if(i===ans){o.classList.add('right')}
        else{o.classList.add('wrong');opts[ans].classList.add('right')}
        if(fb)fb.classList.add('show');
      });
    });
  });

  // earnings calculator
  var sl=document.getElementById('acct');
  if(sl){
    var plan=99, mrrPct=MRRPCT, months=MRRMONTHS, setupComm=SETUPCOMM;
    var out1=document.getElementById('o1'),out2=document.getElementById('o2'),out3=document.getElementById('o3');
    var bars=document.getElementById('bars'), cap=document.getElementById('bcap');
    function draw(){
      var perMonthNew=parseInt(sl.value,10);
      document.getElementById('acctv').textContent=perMonthNew;
      var html='',peak=0,vals=[];
      for(var m=1;m<=24;m++){
        var live=0;
        for(var k=1;k<=m;k++){ if(m-k<months) live+=perMonthNew; }
        var inc=perMonthNew*setupComm + live*plan*mrrPct/100;
        vals.push(inc); if(inc>peak)peak=inc;
      }
      for(var m=0;m<24;m++){
        var h=peak? Math.max(2,Math.round(vals[m]/peak*96)):2;
        html+='<i class="'+(m===11?'on':'')+'" style="height:'+h+'px" title="Month '+(m+1)+': £'+Math.round(vals[m])+'"></i>';
      }
      bars.innerHTML=html;
      out1.textContent='£'+Math.round(vals[0]).toLocaleString();
      out2.textContent='£'+Math.round(vals[11]).toLocaleString();
      out3.textContent='£'+Math.round(vals[23]).toLocaleString();
      cap.innerHTML='<span>Month 1</span><span>Month 24</span>';
    }
    sl.addEventListener('input',draw); draw();
  }
})();
"""

def page(title, track, kick, h1, lede, mods, backline=True):
    out = []
    out.append('<!DOCTYPE html><html lang="en-GB"><head>')
    out.append('<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">')
    out.append(f'<title>{html.escape(title)}</title>')
    out.append('<style>' + CSS + '</style></head>')
    out.append(f'<body data-track="{track}">')
    out.append('<div class="shell">')
    out.append('<div class="top"><div class="brandrow"><b>FRAME EMPIRE</b>'
               f'<span class="pill">{html.escape(kick)}</span>'
               '<span style="margin-left:auto">Your progress saves in this browser</span></div>'
               '<div class="prog"><i id="pbar"></i></div></div>')
    out.append(f'<header class="hero"><p class="kick">{html.escape(kick)}</p>'
               f'<h1>{h1}</h1><p class="lede">{lede}</p></header>')
    for i, (t, sub, body) in enumerate(mods, 1):
        out.append('<details class="mod"><summary>'
                   f'<span class="num">{i:02d}</span>'
                   f'<span class="stitle"><b>{t}</b><em>{sub}</em></span>'
                   '<span class="chev">&#9656;</span></summary>'
                   f'<div class="body">{body}</div></details>')
    out.append('<div class="foot">')
    if backline:
        out.append('<a class="backlink" href="FE_Training_Hub.html">&#8592; Back to the training hub</a><br><br>')
    out.append('Frame Empire Ltd, registered in England and Wales, company number 16163944. '
               'This material is for Frame Empire contractors. Do not forward it to anyone outside the team.'
               '</div></div>')
    js = (JS.replace('MRRPCT', str(N["mrr_pct"]))
            .replace('MRRMONTHS', str(N["mrr_months"]))
            .replace('SETUPCOMM', str(N["r_setup_comm"])))
    out.append('<script>' + js + '</script></body></html>')
    return "\n".join(out)


def quiz(items):
    """items: list of (question, [options], correct_index, feedback)"""
    h = ['<div class="quiz">']
    for q, opts, ans, fb in items:
        h.append(f'<div class="q" data-ans="{ans}"><p>{q}</p>')
        for o in opts:
            h.append(f'<button class="opt" type="button">{o}</button>')
        h.append(f'<p class="fb">{fb}</p></div>')
    h.append('</div>')
    return "".join(h)
