#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Content for the Websites sales track."""
from build_tracks import N, gbp, quiz

def mods():
    M = []

    # ---------------------------------------------------------------- 1
    M.append(("What you are selling", "One product, three prices, and the rule that keeps them legal", f"""
<p>Frame Empire builds professional websites for UK businesses. The client pays <strong>once</strong>. They own it
forever. There is no monthly contract, no lock-in, and nothing hidden in small print you have to talk your way around.</p>

<p>That single fact is your strongest asset on a call, because almost every competitor the prospect has spoken to
wanted a monthly fee. Lead with it.</p>

<h2>The three prices</h2>
<div class="tiers">
  <div class="tier lead"><div class="r1"><span class="nm">Premium Business Website</span><span class="pr">{gbp(N['w_premium'])}</span></div>
  <div class="sub">You always open here. Every single call. This is the price, not the starting point of a haggle.</div></div>
  <div class="tier"><div class="r1"><span class="nm">Special Business Offer</span><span class="pr">{gbp(N['w_special'])}</span></div>
  <div class="sub">Used during the sales process when the Premium is genuinely out of reach for that business.</div></div>
  <div class="tier"><div class="r1"><span class="nm">Final Follow-Up Offer</span><span class="pr">{gbp(N['w_final'])}</span></div>
  <div class="sub">Approval from the director first. Every time. No exceptions, no "I was sure he would say yes".</div></div>
</div>

<h2>Your commission</h2>
<p>Your base rate is <strong>{N['base_pct']}% of the sale price</strong>.</p>
<div class="tw"><table>
<tr><th>Sale price</th><th>Your base commission</th></tr>
<tr><td>{gbp(N['w_premium'])}</td><td class="n">{gbp(N['w_premium_comm'])}</td></tr>
<tr><td>{gbp(N['w_special'])}</td><td class="n">{gbp(N['w_special_comm'])}</td></tr>
<tr><td>{gbp(N['w_final'])}</td><td class="n">{gbp(N['w_final_comm'])}</td></tr>
</table></div>
<p>If you have chosen to work with a coach or a closer, their share comes out of your commission and it is shown on
your statement. It is never an extra charge to you, and you can change that choice at any time.</p>

<div class="note law"><b>The rule that keeps these three prices legal</b>
Advertising a "was {gbp(N['w_premium'])}, now {gbp(N['w_special'])}" saving is only lawful if {gbp(N['w_premium'])} is a
real price that real customers actually pay. So open on the Premium and mean it. Never invent a deadline. Never say the
price is going up next week unless it is. Never say an offer ends on Friday unless it does. Inventing urgency is a
misleading price claim under UK consumer protection law, not a sales technique, and it is the company that carries
the liability.</div>

<div class="note never"><b>Things you must never promise</b>
A position on Google. A number of visitors. A number of enquiries. A guaranteed date the site goes live. You do not
control any of those, and promising them turns a happy client into a refund and a complaint.</div>
"""))

    # ---------------------------------------------------------------- 2
    M.append(("Who to call", "Sixty seconds of research beats an hour of dialling", """
<p>The single biggest difference between a caller who makes money and one who does not is <strong>who they dial</strong>,
not what they say. A brilliant pitch to the wrong business still ends in no.</p>

<h2>Good signs</h2>
<ul>
<li>A real trading business with a phone number you can actually reach</li>
<li>No website at all, or one that clearly has not been touched in years</li>
<li>The owner answers their own phone</li>
<li>They already have reviews somewhere, so they care what people think of them</li>
<li>They sell something where a customer would want to look before they ring</li>
</ul>

<h2>Bad signs, skip them</h2>
<ul>
<li>A chain or a franchise. The person answering cannot buy anything</li>
<li>A site that is obviously recent and professional. You have nothing to offer</li>
<li>Anyone who has already said no twice. Move on and log it</li>
<li>Anyone on a "do not call" note in the CRM. That note exists for a reason</li>
</ul>

<h2>The sixty second check, before you dial</h2>
<ol>
<li>Search the business name. Is there a website? Open it.</li>
<li>Look at it on your phone. Does it work? Most old sites do not.</li>
<li>Note one specific thing you can mention. Not a generic insult, an observation.</li>
<li>Check the reviews. If they have good ones and no site, that is your best call of the day.</li>
</ol>

<div class="note good"><b>Why that one specific thing matters</b>
"I had a look at your site and it does not really work on a phone" beats "I help businesses with their websites" every
time, because the first one proves you actually looked and the second one sounds like a robot reading a list.</div>
"""))

    # ---------------------------------------------------------------- 3
    M.append(("The first fifteen seconds", "Who you are, why you rang, and permission to carry on", """
<p>You get roughly fifteen seconds before the person on the other end decides whether you are worth listening to.
Do not waste them on pleasantries.</p>

<div class="dont">Hi, how are you today? ... Is that the owner? ... Great, and how is your day going?</div>
<p>Everybody who has ever been sold to recognises that opening. It tells them you are a stranger who wants something
and will not say what.</p>

<h2>Three openers that work. Use the words.</h2>
<div class="say">Hi, is that [name]? My name is [your name], I am calling from Frame Empire. I had a look at your
business online and I noticed you have not got a website. Is that right?</div>

<div class="say">Hi [name], [your name] from Frame Empire. Quick one and I will not keep you. I had a look at your site
on my phone and it does not really load properly. Did you know that?</div>

<div class="say">Hi [name], it is [your name] at Frame Empire. I build websites for [their trade] around [their area].
Have you got two minutes or have I caught you on a job?</div>

<h2>The permission line</h2>
<p>That last part matters more than people think. "Have I caught you on a job" gives them an easy honest exit, and
because you offered it, most people will give you the two minutes instead of taking it. It also gets you a real
callback time instead of a fake one.</p>

<div class="note good"><b>If they are busy</b>
Get a specific time, not "later". <em>"No problem at all. Is it better if I try you about four, or is tomorrow
morning easier?"</em> Two options beats an open question. Then log it in the CRM and actually ring at four.</div>
"""))

    # ---------------------------------------------------------------- 4
    M.append(("The offer that removes the risk", "We build it first. They only pay if they like it.", f"""
<p>This is the heart of the whole pitch and it is the reason the sale is winnable at all.</p>

<div class="say">Here is how we work. We build the site first, and we send it to you to look at. If you like it, you pay.
If you do not like it, you do not pay, and you have lost nothing but the ten minutes you are giving me now.</div>

<p>Sit in the silence after that. Do not fill it. The prospect is doing arithmetic in their head and the answer is
always the same: there is no downside.</p>

<h2>What you can honestly say</h2>
<ul>
<li>They see it before they pay a penny</li>
<li>Typically <strong>{N['w_preview_hours']}</strong> to get a preview in front of them</li>
<li>Paid once, owned forever, no monthly fee</li>
<li>Works properly on a phone, which is where most of their customers are</li>
<li>If they want changes before they pay, they get them</li>
</ul>

<div class="note law"><b>Say {N['w_preview_hours']}, not "24 hours"</b>
Give the honest range. One late preview on a promise of 24 hours costs you more goodwill than the wider range ever
cost you a sale, and it is the difference between a delay and a broken promise.</div>

<h2>Why we can do it this way</h2>
<p>If a prospect asks how that is possible, tell them the truth. It is fast because it is a focused build, not a
six-week agency project with four meetings. That is an honest answer and it lands better than a mysterious one.</p>
"""))

    # ---------------------------------------------------------------- 5
    M.append(("The first no", "Almost everybody says it. It usually is not a decision.", """
<p>The first no arrives before the prospect has heard anything. It is a reflex, the same one you use on a stranger in
the street. It is not a decision about your offer, because they do not know your offer yet.</p>

<h2>The one-response rule</h2>
<p>You get <strong>one</strong> honest response to the first no. Not three. Not a script battle. One. If the second no
comes, you thank them and you go.</p>
<p>This is not softness. A caller who argues burns the number, the company's name and their own energy for the next
forty calls. A caller who leaves cleanly can ring back in three months and be welcome.</p>

<h2>Four honest lines that earn you a second sentence</h2>
<div class="say">No problem at all. Can I just ask, is it that you do not want a website, or that you have been quoted
silly money for one before?</div>
<div class="say">That is fair. Just so I do not waste your time again, is it a never, or a not right now?</div>
<div class="say">Understood. Can I leave you with one thing? We build it first and you only pay if you like it. If
that changes anything, my number will be on your phone.</div>
<div class="say">Fine, I will not push it. Out of interest, where do your customers find you at the moment?</div>

<h2>Why these are allowed and other lines are not</h2>
<p>Every one of those is a genuine question with a real answer, and every one gives the prospect an easy way to end
the call. None of them pretends the no did not happen, none of them invents pressure, and none of them makes a claim
that is not true.</p>

<div class="note never"><b>Lines we never use</b>
"Just before you go" as a way to restart a closed call. Fake scarcity. "My manager will kill me." Pretending to be
calling back about an enquiry they never made. Anything that implies you already have a relationship you do not have.
Any one of these gets the company complained about, and it is not worth a {gbp(250)} commission.</div>

<div class="note good"><b>Log every objection in the CRM</b>
Not for a manager to check up on you. Because the objection you heard nine times this week is the one we can answer
properly in the next version of this page, and then you stop hearing it.</div>
""".replace("{gbp(250)}", "£250")))

    # ---------------------------------------------------------------- 6
    M.append(("The five real objections", "Word for word, with the reason each answer works", f"""
<div class="obj"><p class="they">That is too expensive.</p>
<p>Almost never about the number. It is about risk. Answer the risk, not the price.</p>
<div class="say">I understand. Can I ask what you were expecting? The reason I ask is that you do not pay anything
until you have seen it. So if it is not worth {gbp(N['w_premium'])} to you when you look at it, you just say so and
that is the end of it.</div>
<p>If they genuinely cannot reach {gbp(N['w_premium'])} and the business is real, that is when the
{gbp(N['w_special'])} exists. Not before.</p></div>

<div class="obj"><p class="they">I have got a Facebook page.</p>
<div class="say">A lot of my clients did. The difference is you do not own the Facebook page, and it does not come up
when somebody searches for [their trade] in [their town]. Where does a new customer go if they want to check you are
real before they ring?</div>
<p>You are not attacking Facebook. You are pointing at a gap it does not fill.</p></div>

<div class="obj"><p class="they">I need to think about it.</p>
<p>Usually means one unspoken question. Find it.</p>
<div class="say">Of course. Just so I know I have explained it properly, what is the bit you want to think about? Is
it the money, or is it whether it is any good?</div>
<p>Then answer the one they name. Do not re-pitch the whole thing.</p></div>

<div class="obj"><p class="they">Send me an email.</p>
<p>Sometimes real, usually a polite exit. Test it honestly, do not fight it.</p>
<div class="say">I can do that. Can I check one thing first so I send you something useful rather than a brochure?
What would actually make you say yes to a website this year?</div>
<p>If they answer, you are back in a conversation. If they will not, send the email, log it and move on. A real email
address given willingly is worth a follow-up.</p></div>

<div class="obj"><p class="they">How do I know you are real?</p>
<p>The best objection you will hear all day, because it is answerable with facts.</p>
<div class="say">Completely fair, you do not know me. Frame Empire Limited, company number 16163944, registered in
England and Wales. You can look us up on Companies House right now while I am on the phone. And you do not send money
to me, ever. You pay the company directly, and only after you have seen the site.</div>
<p>Let them look it up. Wait. Nothing you can say builds trust as fast as being happy to be checked.</p></div>
"""))

    # ---------------------------------------------------------------- 7
    M.append(("The close", "Confirm the price out loud, then send the link", f"""
<h2>Step one: say the number</h2>
<p>Never let a client reach the payment screen and see a number they have not heard you say. That is how refunds and
chargebacks start.</p>
<div class="say">So that is the Premium Business Website at {gbp(N['w_premium'])}, paid once, and it is yours. Nothing
monthly, nothing after. Are you happy with that?</div>
<p>Wait for an actual yes. "Mmm" is not a yes.</p>

<h2>Step two: send the right link</h2>
<p>The payment links live in <strong>Setup and Tools</strong>. Send the one that matches the price you agreed. Sending
the wrong link is the single most common avoidable mistake on this team.</p>

<h2>Step three: stay on the line</h2>
<div class="say">I will stay on while it comes through, in case anything looks odd. It is the normal card page, you
will see Frame Empire on it.</div>
<p>People abandon payment pages when they are alone and unsure. Two minutes of your time here is worth more than
twenty more dials.</p>

<div class="note never"><b>You never handle client money</b>
You do not take card numbers. You do not take a bank transfer to your own account. You do not accept cash. You do not
accept payment through any link that is not the official Frame Empire one. Every payment goes to Frame Empire, and
your commission follows within seven days of it clearing. Anyone who asks you to do it differently, including someone
claiming to be from Frame Empire, is not from Frame Empire. Tell the director.</div>

<h2>Step four: mark it in the CRM immediately</h2>
<p>Mark Sold, enter the agreed price, fill in the brief. If it is not in the CRM it did not happen, and your
commission is calculated from the CRM.</p>
"""))

    # ---------------------------------------------------------------- 8
    M.append(("The brief", "Ten minutes here saves you a week of chasing", """
<p>The brief is not admin. It is the thing that decides whether this sale finishes cleanly or drags on for three weeks
while somebody chases the client for a logo.</p>

<p>Collect all of it <strong>on the call</strong>, while they are still excited, not by email afterwards.</p>

<ul class="chk">
<li>Exact business name, spelled out, as they want it to appear</li>
<li>What they do, in their own words, one or two sentences</li>
<li>The areas they cover</li>
<li>Phone number and email they want customers to use</li>
<li>Opening hours</li>
<li>Their main services, listed</li>
<li>Do they want prices shown, and if so which ones</li>
<li>Social media links they actually use</li>
<li>Do they have a logo, and can they send it now on WhatsApp</li>
<li>Photos of their own work, if they have any</li>
<li>Any website or business they like the look of</li>
<li>Anything that must not appear on the site</li>
</ul>

<div class="note good"><b>The logo test</b>
Ask them to send the logo on WhatsApp while you are still on the phone. If it arrives, the sale is real and the build
can start. If they say they will send it later, ask again before you hang up. "Later" is where projects go to die.</div>
"""))

    # ---------------------------------------------------------------- 9
    M.append(("After the sale", "Your reputation is worth more than the commission", """
<p>The sale is not finished when the money clears. It is finished when the client is happy with what they got.</p>

<ul>
<li>Tell them what happens next and when, in plain words</li>
<li>If a change is needed, log it properly rather than promising it yourself</li>
<li>If something slips, tell them before they have to ask. A client who is told about a delay is annoyed for a minute.
A client who finds out on their own is gone.</li>
<li>Once they are happy, that is the moment to ask if they know anyone else. Not before.</li>
</ul>

<div class="say">Now that you are happy with it, can I ask you something? Do you know anybody else running a business
round there who is in the same boat you were in?</div>

<p>A referral from a happy client is the easiest sale you will ever make, and it costs you one question asked at the
right moment.</p>
"""))

    # ---------------------------------------------------------------- 10
    M.append(("Knowledge check", "Nine questions. Get them all right before your first real call.",
        quiz([
            ("Which price do you open on, on every call?",
             [gbp(N['w_final']), gbp(N['w_special']), gbp(N['w_premium']), "Whatever feels right for that business"],
             2,
             f"Always the Premium at {gbp(N['w_premium'])}. The lower prices only exist because the Premium is real and people pay it. Opening lower makes the higher price a fiction, which is also what makes it unlawful to advertise as a saving."),

            ("The client says the price is too high. What do you do first?",
             ["Drop straight to " + gbp(N['w_special']),
              "Ask what they were expecting, and remind them they pay nothing until they have seen it",
              "Tell them the price goes up next week",
              "End the call politely"],
             1,
             "Price objections are usually risk objections. Answer the risk first. The lower price exists for businesses that genuinely cannot reach the Premium, not as a reflex."),

            ("Who can approve the " + gbp(N['w_final']) + " Final Follow-Up Offer?",
             ["You can, if you think the sale needs it", "Your coach", "The director, every time", "Anyone with manager CRM access"],
             2,
             "The director, every single time. There is no version of this where you decide on your own and explain afterwards."),

            ("A prospect says no within the first ten seconds. How many responses do you get?",
             ["As many as it takes", "Three", "One honest response, then you thank them and go", "None, hang up"],
             2,
             "One. The first no is a reflex, so one honest question is fair. The second no is a decision, and arguing with it costs you the number, the company's name and your own energy."),

            ("What is your base commission on a " + gbp(N['w_premium']) + " sale?",
             [gbp(250), gbp(N['w_premium_comm']), gbp(200), "20% of the sale"],
             1,
             f"{gbp(N['w_premium_comm'])}. Your base rate is {N['base_pct']}% of the sale price. A coach or closer share comes out of that and appears on your statement, and it is your choice to have one."),

            ("A client wants to pay you by bank transfer because it is easier. What do you say?",
             ["Give them your account details", "Take it and pass it on to the company",
              "Explain that all payments go directly to Frame Empire through the official link",
              "Ask your coach to take it instead"],
             2,
             "You never handle client money in any form. Every payment goes to Frame Empire through the official link, and your commission follows within seven days of it clearing."),

            ("How long do you tell a prospect it takes to see a preview?",
             ["24 hours", N['w_preview_hours'], "Same day", "About a week"],
             1,
             f"{N['w_preview_hours']}. Give the honest range. A preview that lands in 30 hours is early against the range and late against a 24 hour promise, and it is the same 30 hours."),

            ("Which of these can you promise a client?",
             ["That they will appear on the first page of Google", "A number of new enquiries",
              "That they see the site before they pay anything", "A guaranteed live date"],
             2,
             "Only the last one is fully within our control, and it happens to be the strongest thing you have. Search positions, traffic and enquiry numbers depend on things nobody controls, so promising them creates a refund."),

            ("When is the right moment to ask a client for a referral?",
             ["On the first call", "Immediately after they pay", "Once the site is live and they have said they are happy", "In the brief"],
             2,
             "After they are happy. A referral asked for too early is a favour you have not earned yet, and it puts a nervous client on the spot before they know the outcome."),
        ])))

    return M
