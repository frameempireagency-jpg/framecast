#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Content for the AI Receptionist sales track."""
from build_tracks import N, gbp, pence, quiz

def mods():
    M = []

    # ---------------------------------------------------------------- 0
    M.append(("Before you sell a single one of these", "Read this first. It is not optional.", f"""
<div class="note gate"><b>This product is not a website</b>
A website is a thing you hand over once. This is a service that runs every day on the client's behalf and answers
their phone to their customers. If it is set up badly, their customer hears it, not you. That changes how carefully
you have to sell it.</div>

<h2>You may not start dialling until all four of these are true</h2>
<ul class="chk">
<li>The demo number below is filled in and you have rung it yourself, at least twice, and heard what a customer hears</li>
<li>You have read the honest limits in section 02 and you can say them out loud without flinching</li>
<li>You have signed the Product Schedule that covers receptionist commission, because your existing agreement covers
website commission only</li>
<li>You know where to send a client who has a problem at 9pm, and it is not you</li>
</ul>

<div class="note law"><b>The demo number</b>
<span style="font-size:19px;font-family:var(--display)">{N['demo_number']}</span><br>
If that says NOT SET, the product is not ready for you to sell and you should be on the Websites track today. Ask the
director. Do not improvise a demo, and do not describe what it sounds like from memory.</div>

<div class="note never"><b>The one thing that will get this product shut down</b>
Overselling it. If you tell a plumber it is "just like having a receptionist" and it then fails to handle a burst pipe
at midnight the way a human would, you have not lost a sale, you have created a refund, a bad review and a business
owner who tells every other plumber he knows. Sell what it actually does. What it actually does is enough.</div>
"""))

    # ---------------------------------------------------------------- 1
    M.append(("The problem you are actually solving", "A missed call is a lost job, and they already know it", f"""
<p>You are not selling artificial intelligence. Nobody wakes up wanting artificial intelligence. You are selling the
end of a specific, daily, irritating problem that the business owner already knows they have.</p>

<h2>When small businesses miss calls</h2>
<ul>
<li>While they are on a job with their hands full</li>
<li>While they are driving</li>
<li>After about six in the evening, which is exactly when people ring tradesmen</li>
<li>Weekends</li>
<li>While they are already on another call</li>
<li>Every single day they take off</li>
</ul>

<p>The owner does not need convincing that this happens. They live it. Your job is to make them do the arithmetic out
loud, with their own numbers.</p>

<div class="note law"><b>Use their numbers, never invented ones</b>
Do not quote a statistic. Do not say "studies show 80% of callers do not leave a voicemail". You do not have a source
for that and if they ask you for one you are finished. Ask them how many calls they miss and what a job is worth,
then do the sum with what they gave you. It is more persuasive anyway, because they cannot argue with their own
figures.</div>

<h2>The arithmetic, done with them</h2>
<div class="say">Can I just do a quick sum with you? You said you probably miss five or six calls a week. And you said
an average job is worth about two hundred quid. So if even one of those six would have booked, that is eight hundred
pounds a month walking past you. Does that sound about right to you, or am I miles off?</div>

<p>Then stop talking. Let them correct your numbers. When they correct your numbers they are doing the selling for
you, because now it is their calculation, not yours.</p>
"""))

    # ---------------------------------------------------------------- 2
    M.append(("What it is, and what it is not", "The honest limits. Learn these before the features.", f"""
<h2>What it does</h2>
<ul>
<li>Answers every call, first ring, twenty four hours a day, including weekends and Christmas</li>
<li>Speaks naturally. It is a conversation, not a phone menu with buttons</li>
<li>Takes the caller's name, number, and what they are ringing about</li>
<li>Answers questions the client has given it answers to: opening hours, areas covered, services, whether they do
emergencies, roughly what things cost if the client wants that shared</li>
<li>Works out whether something sounds urgent and flags it</li>
<li>Sends the message to the client straight away, by text, email or WhatsApp, whichever they want</li>
<li>Never puts anyone on hold, never gets flustered, never has a bad day</li>
</ul>

<h2>What it is not, and you must say so</h2>
<div class="note never"><b>Say these out loud on the call, before they ask</b>
<ul style="margin:8px 0 0">
<li>It is not a person, and it says so. It introduces itself as an assistant. It will never pretend to be a member of
staff, because that would be lying to their customer on their behalf.</li>
<li>It cannot make judgement calls. It takes the message and flags it as urgent. It does not decide whether to send
someone out at 2am.</li>
<li>It cannot quote a price it has not been given. If the client has not told it, it says it will get someone to
ring back.</li>
<li>It will occasionally mishear an unusual name or a bad line, the same as a person would.</li>
<li>It does not replace the client. It stops them losing the call while they get to the phone.</li>
</ul></div>

<h2>Why saying that wins you the sale</h2>
<p>Every competitor selling this is promising magic. When you are the one who says "here is what it cannot do", two
things happen. The prospect believes the rest of what you said, and their expectations are set where the product can
actually meet them. That second one is why your clients stay past month three, and your commission depends on them
staying.</p>

<div class="say">I will be straight with you. It is not a person and it does not pretend to be one, it says it is an
assistant. What it does is make sure that at seven at night, when somebody rings you and you are eating your dinner,
they talk to something instead of nothing, and you get their name and number on your phone before they have rung
the next bloke on the list.</div>
"""))

    # ---------------------------------------------------------------- 3
    M.append(("Who to call", "Businesses that live and die by the phone", """
<p>The website track sells to businesses that need to be found. This one sells to businesses that <strong>already get
rung</strong> and cannot always answer.</p>

<h2>Best fits</h2>
<ul>
<li><strong>Trades.</strong> Plumbers, electricians, roofers, builders, gas engineers, locksmiths. Hands full all day,
and emergency work comes in out of hours.</li>
<li><strong>Garages and mobile mechanics.</strong> Under a car, phone ringing.</li>
<li><strong>Salons, barbers, nail and beauty.</strong> With a client, cannot stop.</li>
<li><strong>Clinics, dentists, physios, private practices.</strong> Reception is one person and they go to lunch.</li>
<li><strong>Lettings and estate agents.</strong> Out doing viewings.</li>
<li><strong>Takeaways and small restaurants.</strong> Friday night, nobody near the phone.</li>
<li><strong>Removals, skip hire, scaffolding, waste.</strong> On the road all day.</li>
</ul>

<h2>Poor fits, do not waste your time</h2>
<ul>
<li>Businesses that get almost no phone calls and work entirely online</li>
<li>Anyone with a full-time receptionist who is not going anywhere</li>
<li>Businesses where every call is a long technical conversation that genuinely needs the expert</li>
<li>Anyone regulated in a way that means calls must be handled by a qualified person. If you are not sure, ask before
you pitch</li>
</ul>

<div class="note good"><b>The best lead of all</b>
A business you already sold a website to, who told you during the brief that they are always on a job. You already
have the relationship and the trust. Go back through your own closed deals before you dial a single stranger.</div>
"""))

    # ---------------------------------------------------------------- 4
    M.append(("Discovery: the five questions", "Ask, then shut up. The sale is in their answers.", """
<p>This is a discovery sale, not a pitch sale. If you talk for the first three minutes you have lost. Ask these five,
in this order, and write down what they say.</p>

<h2>1. Who answers the phone at the minute?</h2>
<p>Establishes whether there is a problem at all. If the answer is "me, when I can", you are in.</p>

<h2>2. Roughly how many calls do you reckon you miss in a week?</h2>
<p>Never suggest a number. Whatever they say is the number you will use later, and because they said it they will
defend it.</p>

<h2>3. What happens to a call that comes in at seven in the evening?</h2>
<p>The most useful question on the list. The honest answer is almost always "nothing" or "voicemail, and nobody leaves
one". You do not have to argue that voicemail is bad, they will tell you.</p>

<h2>4. What is one new customer actually worth to you?</h2>
<p>This is the number that makes {gbp(99)} a month look small. Get it from them, not from you.</p>

<h2>5. And when you are on holiday?</h2>
<p>This one usually gets a laugh and then a real answer. It is where the pain lives.</p>

<div class="note good"><b>Then say the sum back to them</b>
Take their own three numbers, say the arithmetic out loud, and ask if you have got it right. You have now built the
business case entirely out of things they said, which is the only version of a business case that a sceptical person
believes.</div>

<div class="dont">Let me tell you about our AI receptionist. It uses advanced artificial intelligence to...</div>
<p>Nobody has ever bought anything because of that sentence.</p>
""".replace("{gbp(99)}", "£99")))

    # ---------------------------------------------------------------- 5
    M.append(("The demo", "Stop selling. Let them hear it.", f"""
<p>This is the moment the sale is won, and it is the moment you should say the least.</p>

<div class="note gate"><b>Demo number</b>
<span style="font-size:19px;font-family:var(--display)">{N['demo_number']}</span><br>
If this is not set, you cannot run this section and you should not be selling this product yet.</div>

<h2>How to run it</h2>
<ol>
<li><div class="say">Rather than me describing it, can I just let you hear it? Have you got thirty seconds? Ring this
number, put it on speaker, and talk to it like you are a customer ringing you.</div></li>
<li>Give them the number slowly. Twice.</li>
<li><strong>Then say nothing.</strong> Not a word while it is talking. This is the hardest and most important
instruction on this page.</li>
<li>When they come back, ask one question and nothing else:
<div class="say">What did you think?</div></li>
</ol>

<h2>Why silence</h2>
<p>Everything you say over the top of the demo is you telling them what to think about something they can hear for
themselves. It reads as nervousness about the product. Confidence here is silence.</p>

<div class="note good"><b>If you cannot get them to ring it</b>
Offer to ring it yourself on speaker while they listen, or send them the number on WhatsApp to try after the call and
book a specific time to ring back. Do not describe what it sounds like. A description of a voice is worth nothing.</div>
"""))

    # ---------------------------------------------------------------- 6
    M.append(("The plans, and what a minute means", "Three plans, one setup fee, and an overage rate you always say out loud", f"""
<div class="tiers">
  <div class="tier"><div class="r1"><span class="nm">{N['r_t1_name']}</span><span class="pr">{gbp(N['r_t1_price'])}<span style="font-size:13px;color:var(--muted)">/mo</span></span></div>
  <div class="sub">{N['r_t1_min']} minutes included. {pence(N['r_t1_over'])} a minute after that. Sole traders and quieter businesses.</div></div>
  <div class="tier lead"><div class="r1"><span class="nm">{N['r_t2_name']}</span><span class="pr">{gbp(N['r_t2_price'])}<span style="font-size:13px;color:var(--muted)">/mo</span></span></div>
  <div class="sub">{N['r_t2_min']} minutes included. {pence(N['r_t2_over'])} a minute after that. Most businesses land here. Open on this one.</div></div>
  <div class="tier"><div class="r1"><span class="nm">{N['r_t3_name']}</span><span class="pr">{gbp(N['r_t3_price'])}<span style="font-size:13px;color:var(--muted)">/mo</span></span></div>
  <div class="sub">{N['r_t3_min']} minutes included. {pence(N['r_t3_over'])} a minute after that. Busy phones, multiple staff, clinics and lettings.</div></div>
</div>

<p><strong>Setup is {gbp(N['r_setup'])}, paid once.</strong> That covers building their answering script, loading their
services, hours, areas and prices, connecting the number and testing it properly before it goes live.</p>

<h2>What a minute actually is</h2>
<p>A minute is a minute of a call being answered. A typical "can you come and look at my boiler" call is about a
minute and a half to two minutes. So {N['r_t1_min']} minutes is roughly 125 to 165 calls a month, and
{N['r_t2_min']} minutes is roughly 300 to 400.</p>

<h2>How to size it honestly</h2>
<div class="say">Roughly how many calls a week do you get in total, not just the missed ones? ... Right, so that is
about [x] a month, and most calls run about two minutes, so you would want the [plan]. That gives you room without
paying for minutes you will never use.</div>

<div class="note law"><b>Always say the overage rate out loud, before they buy</b>
<em>"If you go over the included minutes it is {pence(N['r_t2_over'])} a minute after that, so a busy month costs you a
bit more."</em><br><br>
This is not optional and it is not a detail. A client who gets an unexpected bill will charge it back, complain, and
tell people. A client who was told the rate up front and goes over is a client who is busy and happy. Saying it costs
you nothing. Not saying it costs you the account.</div>

<div class="note never"><b>Never say "unlimited"</b>
It is not unlimited. There are included minutes and a rate after that. Saying unlimited is a misleading claim and it
is also the exact sentence that ends in a refund.</div>
"""))

    # ---------------------------------------------------------------- 7
    M.append(("Objections", "Seven you will hear every week", f"""
<div class="obj"><p class="they">AI sounds robotic. My customers will hate it.</p>
<p>Do not argue. Hand them the evidence.</p>
<div class="say">That is exactly what I thought too. Do me a favour, ring the number and tell me if you still think
that. Thirty seconds.</div>
<p>If they will not ring it, this objection cannot be answered with words. Book a time and get them to hear it.</p></div>

<div class="obj"><p class="they">My customers want to speak to a person.</p>
<div class="say">They do. And at seven at night they are not speaking to a person, they are speaking to nothing.
That is the actual choice here. It is not this instead of you, it is this instead of a missed call.</div>
<p>That reframe is the single most useful sentence in this whole track. Learn it word for word.</p></div>

<div class="obj"><p class="they">What if it gets something wrong?</p>
<div class="say">It might mishear a name on a bad line, the same as you would. But it is not making decisions for you.
It takes the name, the number and what they want, and it sends it to your phone. You are still the one who decides
what to do about it.</div>
<p>Honest, specific, and it lowers what they think they are risking.</p></div>

<div class="obj"><p class="they">It is too expensive.</p>
<p>Compare it to the two things it is actually competing with, using their own number from discovery.</p>
<div class="say">You told me a job is worth about two hundred. So it pays for itself if it catches you one job a month.
And the other option is a part-time receptionist, which is not a hundred pounds a month, it is closer to a
thousand.</div>
<p>If they still cannot justify it, the {N['r_t1_name']} plan at {gbp(N['r_t1_price'])} exists. Do not discount the
setup fee to win a price argument, drop the plan instead.</p></div>

<div class="obj"><p class="they">I have already got voicemail.</p>
<div class="say">You have. How many people actually leave one? ... Right. And the ones who do not leave one, where do
they go? They ring the next name on the list.</div>
<p>Let them answer. They know.</p></div>

<div class="obj"><p class="they">Someone from your company told me monthly plans are a con.</p>
<p>You will hear this, because our website pitch attacks pay-monthly websites and it is right to. Do not get flustered
and do not contradict your colleague. The distinction is real.</p>
<div class="say">He is right about websites. A website is a thing you should own outright, like your van, so paying
rent on one forever is a bad deal and we will not do it to you. This is not a thing, it is somebody answering your
phone at seven at night. Nobody buys a receptionist outright either. You buy a thing, you rent a service.</div>
<p>Learn that last sentence word for word. It makes us look consistent rather than caught out, and it is true.</p></div>

<div class="obj"><p class="they">I will think about it.</p>
<div class="say">No problem. Can I ask what the bit is you want to think about, so I know I explained it properly? Is
it whether it sounds any good, or is it the money?</div>
<p>Then answer that one thing. Do not re-pitch. If they will not name it, get a specific callback time and log it.</p></div>
"""))

    # ---------------------------------------------------------------- 8
    M.append(("The close", "Setup plus the first month, then confirm what happens next", f"""
<h2>Say all three numbers out loud</h2>
<div class="say">So that is the {N['r_t2_name']} plan. {gbp(N['r_setup'])} to set it all up, then
{gbp(N['r_t2_price'])} a month, and that includes {N['r_t2_min']} minutes of calls answered. If you go over it is
{pence(N['r_t2_over'])} a minute after that. Happy with that?</div>
<p>Setup fee, monthly price, included minutes, overage rate. All four, every time, out loud, before any payment link
goes anywhere.</p>

<h2>Then set the expectation for going live</h2>
<div class="say">Once that is through, I will take you through about ten minutes of questions so we can teach it your
business properly. Then we test it together before it answers a single real call. You will hear it before your
customers do.</div>

<p>That last sentence removes almost all of the remaining fear, and it is true.</p>

<div class="note never"><b>Same money rule as websites</b>
You never take card details, bank transfers or cash. Everything goes to Frame Empire through the official link. If
anyone, including someone claiming to be from Frame Empire, asks you to take a payment another way, do not, and tell
the director.</div>

<h2>Mark it in the CRM straight away</h2>
<p>Plan, setup fee, start date, and the onboarding answers from the next section. Your recurring commission is
calculated from the CRM record, so a missing record is a missing payment.</p>
"""))

    # ---------------------------------------------------------------- 9
    M.append(("What you earn, and why the small number is the big one",
              "The bit that makes people give up on this product before they understand it", f"""
<h2>The two parts</h2>
<div class="tw"><table>
<tr><th>Part</th><th>What you get</th></tr>
<tr><td>Setup fee ({gbp(N['r_setup'])})</td><td class="n">{N['setup_pct']}% = {gbp(N['r_setup_comm'])} once</td></tr>
<tr><td>Monthly subscription</td><td class="n">{N['mrr_pct']}% every month for {N['mrr_months']} months</td></tr>
</table></div>

<div class="tw"><table>
<tr><th>Plan</th><th>Per month to you</th><th>Total over {N['mrr_months']} months</th></tr>
<tr><td>{N['r_t1_name']} ({gbp(N['r_t1_price'])})</td><td class="n">{gbp(N['r_t1_comm'])}</td><td class="n">{gbp(N['r_t1_total'])}</td></tr>
<tr><td>{N['r_t2_name']} ({gbp(N['r_t2_price'])})</td><td class="n">{gbp(N['r_t2_comm'])}</td><td class="n">{gbp(N['r_t2_total'])}</td></tr>
<tr><td>{N['r_t3_name']} ({gbp(N['r_t3_price'])})</td><td class="n">{gbp(N['r_t3_comm'])}</td><td class="n">{gbp(N['r_t3_total'])}</td></tr>
</table></div>

<h2>The honest comparison</h2>
<p>A website sale at {gbp(N['w_premium'])} pays you {gbp(N['w_premium_comm'])} and then it is over. A
{N['r_t2_name']} sale pays you {gbp(N['r_setup_comm'])} now and {gbp(N['r_t2_comm'])} a month after that. On its own
it looks worse. It is not worse, because it does not stop.</p>

<p>The difference is that a website sale resets you to zero on the first of every month. A receptionist sale does not.
Play with this and see what happens.</p>

<div class="calc">
  <label for="acct">New receptionist clients you close per month: <b id="acctv" style="color:var(--signal)">2</b></label>
  <input type="range" id="acct" min="1" max="8" value="2" step="1">
  <div class="bars" id="bars"></div>
  <div class="barcap" id="bcap"></div>
  <div class="row">
    <div class="cell"><span>Month 1</span><b id="o1">-</b></div>
    <div class="cell"><span>Month 12</span><b id="o2">-</b></div>
    <div class="cell"><span>Month 24</span><b id="o3">-</b></div>
  </div>
  <p class="cap">Assumes the {N['r_t1_name']} plan at {gbp(N['r_t1_price'])}, so this is the pessimistic version.
  Every client on a higher plan pays you more. It also assumes nobody ever cancels, which is not real, so treat the
  shape as the point rather than the exact figure.<br><br>
  It flattens out after month {N['mrr_months']} because the monthly share runs for {N['mrr_months']} months per
  client. The oldest ones drop off as new ones come on, so it settles at a level instead of climbing forever. That
  level is still money arriving every month whether or not you had a good week.</p>
</div>

<div class="note good"><b>What the shape tells you</b>
Month one is small. By month six you are earning from work you did months ago as well as the work you did this month.
That is the entire reason this product exists on top of websites, and it is why the caller who sticks with it for
half a year ends up in a completely different position to the one who gave up in week three because the first cheque
was smaller.</div>

<div class="note law"><b>Your existing agreement does not cover this</b>
Your Frame Empire agreement sets commission at {N['base_pct']}% of the sale price of a website. A monthly subscription
does not have a single sale price, so this product needs a short Product Schedule signed alongside your agreement
before you sell one. If you have not signed it, ask the director. Do not sell on a handshake and work out the
commission afterwards, because that is how people fall out.</div>
"""))

    # ---------------------------------------------------------------- 10
    M.append(("Onboarding the client", "Eleven things, collected once, properly", """
<p>Everything the assistant knows, someone had to tell it. That someone is you, on the onboarding call, and the
quality of this list is the difference between a client who renews and a client who cancels in week three.</p>

<ul class="chk">
<li>Exact business name, and exactly how they want the greeting to sound, word for word</li>
<li>Opening hours, and what should happen outside them</li>
<li>Every service they offer, in their own words, including the ones they do not want mentioning</li>
<li>Areas they cover, and areas they definitely do not</li>
<li>Any prices they are happy for it to say out loud, and the ones it must never quote</li>
<li>What counts as an emergency for them, and exactly what they want done when one comes in</li>
<li>Where messages go: text, email or WhatsApp, and to which number or address</li>
<li>Whether we set up a new number or forward their existing one, and who does that</li>
<li>Three questions their customers ask constantly, with the answers</li>
<li>Anything it must never say, never promise, and never agree to</li>
<li>A named person we ring if something looks wrong</li>
</ul>

<div class="note good"><b>The question that saves you a month of grief</b>
<em>"What is the one thing that would really annoy you if it said it to a customer?"</em><br><br>
Ask it at the end of onboarding. The answers are always specific, always unexpected, and always the thing that would
have caused the complaint.</div>

<h2>Then test it with them</h2>
<p>Ring it together before it goes live. Let them hear their own greeting. Let them try to break it. Five minutes here
converts a nervous buyer into someone who tells other business owners about it.</p>
"""))

    # ---------------------------------------------------------------- 11
    M.append(("The rules, in plain words", "What you must do, and what will get us in trouble", f"""
<h2>It always says what it is</h2>
<p>The assistant introduces itself as an assistant. It never claims to be a named member of staff and it never claims
to be a person. There is currently no specific UK law forcing that disclosure, but actively letting someone believe
they are speaking to a human when they are not risks being treated as a misleading practice under consumer protection
law, and more importantly it is a lie told to somebody else's customer in their name.</p>

<div class="note never"><b>Never use this as a selling point</b>
<em>"Your customers will never know it is not a real person."</em><br>
Do not say it. Do not imply it. It is the sentence that turns a service into a complaint, and it is not true anyway.</div>

<h2>Call recording</h2>
<p>If calls are recorded, the caller must be told. Under UK GDPR the client needs a lawful basis for recording, which
for a business taking enquiries is usually legitimate interests rather than consent, and they must be transparent
about it. The notice is built into the greeting. It is not there to be removed because a client thinks it sounds
formal.</p>

<div class="note law"><b>The data side needs paperwork</b>
When the assistant handles the client's customers' personal data, the client is the data controller and Frame Empire
is the processor. UK GDPR requires that relationship to be set out in a written contract. That is a document the
company needs to have in place before the first client goes live, and it is not something you can promise on a call.
If a client asks about it, tell them you will have the director send it over, and mean it.<br><br>
I am not a lawyer and this is a summary rather than legal advice. It should be checked by someone qualified before
the first paying client is connected.</div>

<h2>Things you must never claim</h2>
<ul>
<li>That it will never make a mistake</li>
<li>That it is unlimited</li>
<li>That it can do anything the client has not told it</li>
<li>That a customer will not be able to tell</li>
<li>That it replaces a member of staff</li>
<li>Any figure or statistic you cannot point at a source for</li>
</ul>

<h2>Calling rules still apply</h2>
<p>Everything in your existing training about who you may call, the do-not-call list and honest openings applies here
exactly the same. A new product does not come with new permissions.</p>
"""))

    # ---------------------------------------------------------------- 12
    M.append(("Knowledge check", "Ten questions. All ten before you sell one.",
        quiz([
            ("Before you dial for this product, which of these must be true?",
             ["You have read this page",
              "You have rung the demo number yourself and heard what a customer hears",
              "You have sold at least one website",
              "Your coach has approved you"],
             1,
             "You cannot sell a voice you have never heard. Ringing it yourself is the minimum, and if the demo number is not set then the product is not ready to be sold at all."),

            ("A prospect asks how many callers leave a voicemail. You do not have a source. What do you say?",
             ["Tell them about 80%, everyone knows that",
              "Make a reasonable estimate and say roughly",
              "Turn it back into a question and use their own experience",
              "Say you will find out and ring back"],
             2,
             "Ask them: 'How many people actually leave you one?' You do not need a statistic, and quoting one you cannot source is how you lose credibility in a single sentence."),

            ("What is the single most important thing to do during the demo?",
             ["Explain the technology while it talks", "Point out the good bits as they happen",
              "Say nothing at all until they come back", "Keep them on mute"],
             2,
             "Silence. Anything you say over the top of the demo reads as nervousness about the product and stops them forming their own opinion, which is the only opinion that will close them."),

            ("Which four numbers must you say out loud before any payment link is sent?",
             ["Just the monthly price", "Monthly price and setup fee",
              "Setup fee, monthly price, included minutes, overage rate", "Setup fee and included minutes"],
             2,
             "All four, every time. The overage rate is the one people skip and it is the one that causes chargebacks and cancellations."),

            ("A client says AI sounds robotic. What is the best response?",
             ["Explain how the technology has improved", "Ask them to ring the number and judge for themselves",
              "Agree and offer a discount", "Tell them their customers will not be able to tell"],
             1,
             "Hand them the evidence instead of arguing. And never tell them their customers will not be able to tell, which is both untrue and the exact claim that creates complaints."),

            ("A prospect says their customers want to speak to a real person. What is the reframe?",
             ["Most people prefer AI now", "It is not this instead of you, it is this instead of a missed call",
              "You can always ring them back", "It sounds like a real person anyway"],
             1,
             "That is the most useful sentence in this track. At seven in the evening the actual choice is not human versus AI, it is something versus nothing."),

            (f"On the {N['r_t2_name']} plan, what do you earn in total over {N['mrr_months']} months?",
             [gbp(N['r_setup_comm']), gbp(N['r_t2_comm']), gbp(N['r_t2_total']), gbp(N['w_premium_comm'])],
             2,
             f"{gbp(N['r_setup_comm'])} from the setup fee plus {gbp(N['r_t2_comm'])} a month for {N['mrr_months']} months, which is {gbp(N['r_t2_total'])}. The monthly part is the bit that compounds as you add clients."),

            ("A client cannot justify the price. What do you do?",
             ["Discount the setup fee", "Offer a free month",
              f"Move them to the {N['r_t1_name']} plan", "Tell them the price rises next month"],
             2,
             f"Drop the plan, not the setup fee. The setup work happens either way and the {N['r_t1_name']} plan exists precisely for this. And never invent a price rise."),

            ("Does the assistant tell callers it is not a person?",
             ["Only if asked", "No, that would put people off", "Yes, always, it introduces itself as an assistant",
              "Only outside business hours"],
             2,
             "Always. There is no specific UK statute forcing it today, but letting a caller believe they are talking to a human risks being a misleading practice, and it is a lie told to your client's customer in your client's name."),

            ("Your existing Frame Empire agreement covers commission on what?",
             ["All products", "Websites only", "Websites and subscriptions", "Whatever the CRM says"],
             1,
             "Websites only, at 50% of the sale price. A subscription has no single sale price, so a Product Schedule has to be signed before you sell one. Ask the director if you have not signed it."),
        ])))

    return M
